    ifndef __DATA__
    define __DATA__

	include "constants.asm"

;include SINUS table
	;align 256 ;  TODO check once using, if we can remove the align 256 if this is the first include after org 32768, will avoid wasting RAM
sin:
	incbin "data/sin.bin"
sinX:
	;align 256 ;  TODO check once using, if we can remove the align 256 if this is the first include after org 32768, will avoid wasting RAM
	incbin "data/sin01.bin"
sinY:
	;align 256 ;  TODO check once using, if we can remove the align 256 if this is the first include after org 32768, will avoid wasting RAM
	incbin "data/sin02.bin"		

	
	;align 256 ; TODO check once using, should be able to remove this align also, if data.asm is included at 32768
tileFrames:
		dup 8
		dw tileSet+48*10	
		dw tileSet+48*10
		dw tileSet+48*9
		dw tileSet+48*9
		dw tileSet+48*8
		dw tileSet+48*8
		dw tileSet+48*7
		dw tileSet+48*7
		dw tileSet+48*6
		dw tileSet+48*6
		dw tileSet+48*5
		dw tileSet+48*5
		dw tileSet+48*4
		dw tileSet+48*4
		dw tileSet+48*3
		dw tileSet+48*3
		
		edup    

	;align 256 ; TODO check once using, should be able to remove this align also, if data.asm is included at 32768
tileFrames2:
		dup 16
		dw tileSet+48*12	
		dw tileSet+48*12
		dw tileSet+48*14
		dw tileSet+48*14
		dw tileSet+48*(12+32)
		dw tileSet+48*(12+32)
		dw tileSet+48*(14+32)
		dw tileSet+48*(14+32)
		
		edup  

	;align 256 ; TODO check once using, should be able to remove this align also, if data.asm is included at 32768
tileFrames3:
		dup 16
		dw tileSet+48*13	
		dw tileSet+48*13
		dw tileSet+48*15
		dw tileSet+48*15
		dw tileSet+48*(13+32)
		dw tileSet+48*(13+32)
		dw tileSet+48*(15+32)
		dw tileSet+48*(15+32)	
		
		edup  

	;align 256 ; TODO check once using, should be able to remove this align also, if data.asm is included at 32768
tileFrames4:
		dup 16
		dw tileSet+48*28	
		dw tileSet+48*28
		dw tileSet+48*30
		dw tileSet+48*30
		dw tileSet+48*(28+32)
		dw tileSet+48*(28+32)
		dw tileSet+48*(30+32)
		dw tileSet+48*(30+32)
		
		edup  

	;align 256 ; TODO check once using, should be able to remove this align also, if data.asm is included at 32768
tileFrames5:
		dup 16
		dw tileSet+48*29	
		dw tileSet+48*29
		dw tileSet+48*31
		dw tileSet+48*31
		dw tileSet+48*(29+32)
		dw tileSet+48*(29+32)
		dw tileSet+48*(31+32)
		dw tileSet+48*(31+32)
		
		edup  	

tileUpdateFrames:
	dup 32
	db 1, 1, 1, 1, 1, 1, 0, 0
	edup 				





; playerPosition:
; playerX: db 16
; playerY: db 16

evenFrame: db 0


	endif ; __DATA__