kPlayerStartX = 16
kPlayerStartY = 30


Player_Init:
	ld hl,testSprite 
    ld (sprite00+SPRITE.IMAGE),hl
    
	ld a,kPlayerStartX
    ld (Sprite00X),a
	ld a,kPlayerStartY
    ld (Sprite00Y),a

    ret 

Player_Update:
;processInput
	ld hl,(Sprite00Position)
;P	
    LD    BC,57342
    IN    A,(C)
    BIT 0,A
    jr nz,1f 
	inc l 
	inc l 
	 
	;clamp
	LD a, l
	CP PLAYER_MAX_X
	CALL NC, clampPlayerRight ; If the value is greater than N, call clamp routine
	LD l, a

1: ;O	
    LD    BC,57342
    IN    A,(C)
    BIT 1,A
    jr nz,1f 
	dec l 
	dec l 
	;clamp
	LD a, l
	CP PLAYER_MIN_X
	CALL C, clampPlayerLeft ; If the value is less than N, call clamp routine
	LD l, a	

1: ;Q
    ld bc,64510
    in a,(c)
    BIT 0,A
    jr nz,1f 
    dec h 
    dec h 
	;clamp
	LD a, h
	CP PLAYER_MIN_Y
	CALL C, clampPlayerTop ; If the value is less than N, call clamp routine
	LD h, a		

1: ;A
    ld bc,65022
    in a,(c)
    BIT 0,A
    jr nz,1f 
	inc h 
	inc h 
	;clamp
	LD a, h
	CP PLAYER_MAX_Y
	CALL NC, clampPlayerBottom ; If the value is greater than N, call clamp routine
	LD h, a

1:
	ld (Sprite00Position),hl

; *** TEMP - this prob will end up in the SpriteManager
	; ld a,(Sprite00X) : ld (sprite00_X),a
	; ld a,(Sprite00Y) : ld (sprite00_Y),a
; *** End temp

	ret

clampPlayerTop:
	LD A, PLAYER_MIN_Y
	ret

clampPlayerLeft:
	LD A, PLAYER_MIN_X
	ret

clampPlayerBottom:
	LD A, PLAYER_MAX_Y 
	ret

clampPlayerRight:
	LD A, PLAYER_MAX_X
	ret	
