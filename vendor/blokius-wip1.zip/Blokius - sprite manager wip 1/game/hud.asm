SCORE_PHASE_0_DRAW_xxxx0 = 0
SCORE_PHASE_1_DRAW_xxx0x = 1
SCORE_PHASE_2_DRAW_xx0xx = 2
SCORE_PHASE_3_DRAW_x0xxx = 3
SCORE_PHASE_4_DRAW_0xxxx = 4
SCORE_PHASE_5_UPDATE_ASCII = 5


font:
	incbin "font/n13.bin"			

    
; Text for my print routine that uses zero-terminated strings 
;
SCORE_INITIAL_TEXT: DB "0000000", 0

SCORE_LIVE_TEXT: 
SCORE_LIVE_TEXT_CHAR_0: DB "0"
SCORE_LIVE_TEXT_CHAR_1: DB "0"
SCORE_LIVE_TEXT_CHAR_2: DB "0"
SCORE_LIVE_TEXT_CHAR_3: DB "0"
SCORE_LIVE_TEXT_CHAR_4: DB "0"


scoreValue: dw 0
scorePhase: db 0	


DrawHUDAttributes:
	DRAW_RECT 0, 0, SCORE_CHAR_WIDTH, 1, COLOR_WHITE + ATTRIBUTE_BRIGHT, COLOR_BLACK 
	DRAW_RECT 0, 1, SCORE_CHAR_WIDTH, 1, COLOR_CYAN + ATTRIBUTE_BRIGHT, COLOR_BLACK

	; DRAW_RECT 0, 4, 2, 2, COLOR_YELLOW, COLOR_YELLOW
	; DRAW_RECT 0, 6, 2, 2, COLOR_BLACK + ATTRIBUTE_BRIGHT, COLOR_YELLOW
	; DRAW_RECT 0, 8, 2, 2, COLOR_BLACK + ATTRIBUTE_BRIGHT, COLOR_YELLOW
	; DRAW_RECT 0, 10, 2, 2, COLOR_BLACK + ATTRIBUTE_BRIGHT, COLOR_YELLOW
	; DRAW_RECT 0, 11, 1, 1, COLOR_BLACK + ATTRIBUTE_BRIGHT, COLOR_YELLOW
	; DRAW_RECT 0, 13, 1, 1, COLOR_BLACK + ATTRIBUTE_BRIGHT, COLOR_YELLOW
	; DRAW_RECT 0, 15, 1, 1, COLOR_BLACK + ATTRIBUTE_BRIGHT, COLOR_YELLOW
	; DRAW_RECT 0, 17, 1, 1, COLOR_BLACK + ATTRIBUTE_BRIGHT, COLOR_YELLOW


	ret

; score in phases:
; start with drawing rather than updating, so then the rightmost two digits can always be drawn in a 7/8 cycle
; for cleaner looking updating most of the time, since the score will usually increase by 1(00) and 99(00)
; destroys b,c,hl
UpdateScore:

	push af

	ld a,(scorePhase)

; Calculate the address of the jump table entry
; 	LD HL, ScorePhaseJumpTable
; 	ADD A, A ; Multiply A by 2 because each address in the jump table is 2 bytes long
; 	LD C, A
; 	LD B, 0
; 	ADD HL, BC


; ; Load the address from the jump table and jump to the case label
; 	JP (HL)


    ; Multiply index by 3 (the size of a JP instruction)
    ld b, a
    add a, b
    add a, b
    
    ; Overwrite the following jump with the index and then run
    ; into it (which will jump into the jump table below)
    ld ($+4), a
    jr $
    
    ; Jump table goes here
    jp ScorePhaseCase0
    jp ScorePhaseCase1
    jp ScorePhaseCase2
    jp ScorePhaseCase3
    jp ScorePhaseCase4
    jp ScorePhaseCase5

ScorePhaseCase0: ; xxxx0
	ld a,(SCORE_LIVE_TEXT_CHAR_4)
	ld de,16388
	call PrintCharAtScreenAddress

	ld a,SCORE_PHASE_1_DRAW_xxx0x
	ld (scorePhase),a

	jp ScorePhaseEndSwitch

ScorePhaseCase1: ; xxx0x
	ld a,(SCORE_LIVE_TEXT_CHAR_3)
	ld de,16387
	call PrintCharAtScreenAddress

	ld a,SCORE_PHASE_2_DRAW_xx0xx
	ld (scorePhase),a

	jp ScorePhaseEndSwitch

ScorePhaseCase2: ; xx0xx
	ld a,(SCORE_LIVE_TEXT_CHAR_2)
	ld de,16386
	call PrintCharAtScreenAddress

	ld a,SCORE_PHASE_3_DRAW_x0xxx
	ld (scorePhase),a

	jp ScorePhaseEndSwitch
	
ScorePhaseCase3: ; x0xxx
	ld a,(SCORE_LIVE_TEXT_CHAR_1)
	ld de,16385
	call PrintCharAtScreenAddress

	ld a,SCORE_PHASE_4_DRAW_0xxxx
	ld (scorePhase),a

	jp ScorePhaseEndSwitch

ScorePhaseCase4: ; 0xxxx
	ld a,(SCORE_LIVE_TEXT_CHAR_0)
	ld de,16384
	call PrintCharAtScreenAddress

	ld a,SCORE_PHASE_5_UPDATE_ASCII
	ld (scorePhase),a

	jp ScorePhaseEndSwitch

ScorePhaseCase5: ; update ASCII
    ld hl,(scoreValue)      	
	ld de,SCORE_LIVE_TEXT
	call NumberToAscii

	ld a,SCORE_PHASE_0_DRAW_xxxx0
	ld (scorePhase),a

	jp ScorePhaseEndSwitch

ScorePhaseEndSwitch:
    ; Continue with the rest of the program





	pop af
	ret

DrawScore:
	LD D, CONSOLE_CHAR_X
	LD E, CONSOLE_CHAR_Y
	LD HL, SCORE_INITIAL_TEXT
	CALL PrintString

    ret