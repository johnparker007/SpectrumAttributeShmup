    ifndef __MATH__
    define __MATH__

; destroys de,hl
subtractAfromBCAndStoreToBC:
    LD D,0
    ld e,a

    ld h,b
    ld l,c
    SBC HL, DE

    LD BC, HL

    ret

    endif ; __MATH__