    ifndef __DEFINES__
    define __DEFINES__


; uncomment define for Pentagon timings	
;	define PENTAGON

    define DRAW_SCORE

    endif