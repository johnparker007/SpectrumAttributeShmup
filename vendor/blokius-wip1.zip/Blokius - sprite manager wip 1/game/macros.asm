	include "constants.asm"

;============================================================================	
	macro DRAW_RECT rectX, rectY, rectWidth, rectHeight, colorPaper, colorInk

	;draw rect in buffer

	;get current buffer start pointer
	ld hl,(attrPointer)
	;add displacement
	ld de,rectX+rectY*attrBufferWidth : add hl,de
	
   
    ;ld a,color*8+color;attribute to draw (n * 8 + n where n is 0-7 color)
	;ld a,color;	
	
	ld a,colorInk*8+colorPaper
	
	ld de,attrBufferWidth-rectWidth;buffer width minus rect width

	;draw rect
	ld c,rectHeight;height
2:
    ld b,rectWidth;width
1:
	ld (hl),a : inc hl
	djnz 1b
	add hl,de
	dec c
	jr nz,2b
		
	endm
;============================================================================
	macro SET_BORDER color
		ld a, color
		out (254), a
	endm
;============================================================================
	macro SET_PAGE page
		ld a, 16 + page: ld bc, $7ffd : out (c), a
	endm
;============================================================================
	macro SET_RENDER_FRAME renderFrame
		ld a, DEBUG_DISABLE_RENDER_HALT
		cp 0
		jp nz, 1f
	    halt
1:
		ld hl, renderFrame 
		ld (intProc+1),hl
	endm
;============================================================================
