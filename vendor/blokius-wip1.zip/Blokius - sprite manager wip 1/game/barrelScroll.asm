	include "defines.asm"
	include "constants.asm"
    include "data.asm"
    include "math.asm"
    

    STRUCT BARREL_SCROLL_LUT_STRUCT
DRAW_LEFT_TILE			BYTE 0
DRAW_RIGHT_TILE			BYTE 0
DRAW_LEFT_TILE_COLUMN	BYTE 0
DRAW_RIGHT_TILE_COLUMN	BYTE 0
    ENDS 

sourceTileMapReadIndex: dw 0
sourceTileMapReadColumn: db 0 ; TODO should be able to remove this once replaced by sourceTileMapReadIndex for the rotated tilemap
sourceTileIndex: db 0 ; the tile index to paste into the barrel scroll tilemap

tileMapWriteColumn: dw 0
tileMapWriteRow: dw 0

sourceTileMapRowAddLUT:
	dw 0 * SOURCE_TILEMAP_WIDTH
	dw 1 * SOURCE_TILEMAP_WIDTH
	dw 2 * SOURCE_TILEMAP_WIDTH
	dw 3 * SOURCE_TILEMAP_WIDTH
	dw 4 * SOURCE_TILEMAP_WIDTH
	dw 5 * SOURCE_TILEMAP_WIDTH

tileMapRowAddLUT:
	dw 0 * tileMapWidth
	dw 1 * tileMapWidth
	dw 2 * tileMapWidth
	dw 3 * tileMapWidth
	dw 4 * tileMapWidth
	dw 5 * tileMapWidth	

barrelScrollLUT:
	; bool drawLeftColumn, bool drawRightColumn, byte drawLeftTileColumn, byte drawRightTileColumn
	db	0,	1,	255,9
	db	1,	1,	0,	10
	db	1,	1,	1,	11
	db	1,	1,	2,	12
	db	1,	1,	3,	13
	db	1,	1,	4,	14
	db	1,	1,	5,	15
	db	1,	1,	6,	16
	db	1,	1,	7,	17
	db	1,	0,	8,	255    


barrelScrollLUTIndex: db 0
barrelScrollLUTCurrentRowAddress: dw 0   

barrelScrollFinalColumn: db 0
barrelScrollComplete: db 0

BARREL_SCROLL_LUT_ROW_COUNT = 10


barrelScroll_Init:
    ; copy in initial data, full screen plus one extra column to scroll into
	ld hl, sourceTileMap + ((SCREEN_TILE_WIDTH + 1) * 0) : ld de, tileMap + (tileMapWidth * 0) : ld bc, SCREEN_TILE_WIDTH + 1 : ldir
	ld hl, sourceTileMap + ((SCREEN_TILE_WIDTH + 1) * 1) : ld de, tileMap + (tileMapWidth * 1) : ld bc, SCREEN_TILE_WIDTH + 1 : ldir
	ld hl, sourceTileMap + ((SCREEN_TILE_WIDTH + 1) * 2) : ld de, tileMap + (tileMapWidth * 2) : ld bc, SCREEN_TILE_WIDTH + 1 : ldir
	ld hl, sourceTileMap + ((SCREEN_TILE_WIDTH + 1) * 3) : ld de, tileMap + (tileMapWidth * 3) : ld bc, SCREEN_TILE_WIDTH + 1 : ldir
	ld hl, sourceTileMap + ((SCREEN_TILE_WIDTH + 1) * 4) : ld de, tileMap + (tileMapWidth * 4) : ld bc, SCREEN_TILE_WIDTH + 1 : ldir
	ld hl, sourceTileMap + ((SCREEN_TILE_WIDTH + 1) * 5) : ld de, tileMap + (tileMapWidth * 5) : ld bc, SCREEN_TILE_WIDTH + 1 : ldir

    ; set initial values
    ld a, SCREEN_TILE_WIDTH + 1
    ld (sourceTileMapReadColumn), a
    ld (tileMapWriteColumn), a

    ld a,(SCREEN_TILE_WIDTH + 1) * SOURCE_TILEMAP_HEIGHT
    ld (sourceTileMapReadIndex),a

    ld a, 0
    ld (tileMapWriteRow), a
    ld (barrelScrollLUTIndex),a
    ld (barrelScrollFinalColumn),a
    ld (barrelScrollComplete),a
     
    ret 


barrelScroll_Update:
    call barrelScroll_DoAnimations

    ld a,(barrelScrollComplete)
    cp 0
    jr z, 1f:
    ret 

1:
    call barrelScroll_UpdateDoNextTile
    call barrelScroll_UpdateAdvanceScroll

    ret

barrelScroll_UpdateDoNextTile:
doNextTileFrame:
    ;move through the 256 lookup of frames to draw tiles on
	ld hl,tileUpdateFrames
    ld e,(hl)
    ld d,0
    inc l
    ld (doNextTileFrame+1),hl

    ; Combine D and E using the OR instruction
    LD A, D
    OR E
    ; Jump if the result (A register) is non-zero
    JR NZ, 1f

    ;we're on frame 7/8 so update score instead
    ifdef DRAW_SCORE
        call UpdateScore
    endif

    ret

1:
        ; set correct row address in barrelScrollLUT
        ld de,BARREL_SCROLL_LUT_STRUCT 
        ld a,(barrelScrollLUTIndex)
        call DE_Times_A
        ld de,barrelScrollLUT
        add hl,de; HL is now pointing at the correct row in the LUT
        ld (barrelScrollLUTCurrentRowAddress),hl

        ;calculate tilemap write address
        ld hl, tileMap

        ld bc,(tileMapWriteColumn)
        add hl,bc
        push hl

        ld hl, tileMapRowAddLUT
        ld bc, (tileMapWriteRow)
        add hl,bc ; Add twice since each entry is a 2byte word
        add hl,bc ;  
        
        pop bc

        ; Assuming HL contains the memory address pointer and BC contains a 16-bit number
        ; Add low byte
        LD A, (HL)      ; Load the low byte at the memory address pointed to by HL into the A register
        ADD A, C         ; Add the low byte of BC to the value in the A register
        LD C, A          ; Store the result back to the low byte of BC
        ; Add high byte
        INC HL           ; Increment HL to point to the high byte of the memory address
        LD A, (HL)       ; Load the high byte at the memory address pointed to by HL into the A register
        ADC A, B         ; Add the high byte of BC to the value in the A register, with carry
        LD B, A          ; Store the result back to the high byte of BC
        ; Restore HL to its original value
        ;DEC HL           ; Decrement HL to point back to the low byte of the memory address

        push bc
    ; store next sourceTileIndex
        ld hl, sourceTileMap
        ld bc,(sourceTileMapReadIndex)
        add hl,bc
        ld a, (hl) ; read source tile
        ld (sourceTileIndex),a

        pop bc

    ;should we draw right tile?
        ld ix,(barrelScrollLUTCurrentRowAddress)
        ld a, (ix + BARREL_SCROLL_LUT_STRUCT.DRAW_RIGHT_TILE)
        cp 0
        jr z, 1f 
        ; draw the tile:
        ld a,(sourceTileIndex)
        ld (bc), a ; post target tile
1:
        
    ;should we draw left tile?
        ld a, (ix + BARREL_SCROLL_LUT_STRUCT.DRAW_LEFT_TILE)
        cp 0
        jr z, 1f 
        ; draw the tile:        
        ld a,10
        push hl
        call subtractAfromBCAndStoreToBC
        pop hl
        ld a,(sourceTileIndex)
        ld (bc), a ; post target tile
1:

    
    ; update read tilemap index
        ld hl,1
        ld bc,(sourceTileMapReadIndex)
        add hl,bc
        ld (sourceTileMapReadIndex),hl


    ; update tileMapWriteRow with wraparound
        ld a,(tileMapWriteRow)
        inc a
        cp SCREEN_TILE_HEIGHT
        jr nz, 1f
        ld a, 0

        push af

        ld a,(sourceTileMapReadColumn)
        inc a
        ld (sourceTileMapReadColumn),a

        cp 0 ; has sourceTileMapReadColumn wrapped around?
        jr nz, 4f
        ld a,1 ; has wrapped around, so set barrelScrollFinalColumn
        ld (barrelScrollFinalColumn),a

4:
    ; update tileMapWriteColumn with wraparound
        ld a,(tileMapWriteColumn)
        inc a
        cp tileMapWidth+1
        jr nz, 2f
        ld a, SCREEN_TILE_WIDTH + 1     


2:
        ld (tileMapWriteColumn),a

    ; update the LUT index
        ld a,(barrelScrollLUTIndex)
        inc a
        cp BARREL_SCROLL_LUT_ROW_COUNT
        jr nz, 3f
        ld a,0
3:
        ld (barrelScrollLUTIndex),a

        pop af

1:
        ld (tileMapWriteRow),a  


        ld a,(barrelScrollFinalColumn)
        cp 1
        jr nz, 1f
        ld a,(tileMapWriteRow)
        cp SCREEN_TILE_HEIGHT - 1
        jr nz, 1f
        ld a,1
        ld (barrelScrollComplete),a
1:

    ret 

;very simple tile animation - just change a pointer in tileGFX
barrelScroll_DoAnimations:

; this first one is parallax background, so skip if barrelScrollComplete
	ld a,(barrelScrollComplete)
	cp 1
	jr z, barrelScroll_AnimFrame2
	
barrelScroll_AnimFrame1:
	ld hl,tileFrames : ld e,(hl) : inc l : ld d,(hl) : inc l : ld (barrelScroll_AnimFrame1+1),hl
	ld (tilesLUT+2*3),de ;tile to change

barrelScroll_AnimFrame2:
	ld hl,tileFrames2 : ld e,(hl) : inc l : ld d,(hl) : inc l : ld (barrelScroll_AnimFrame2+1),hl
	ld (tilesLUT+2*12),de ;tile to change		

barrelScroll_AnimFrame3:
	ld hl,tileFrames3 : ld e,(hl) : inc l : ld d,(hl) : inc l : ld (barrelScroll_AnimFrame3+1),hl
	ld (tilesLUT+2*13),de ;tile to change

barrelScroll_AnimFrame4:
	ld hl,tileFrames4 : ld e,(hl) : inc l : ld d,(hl) : inc l : ld (barrelScroll_AnimFrame4+1),hl
	ld (tilesLUT+2*28),de ;tile to change

barrelScroll_AnimFrame5:
	ld hl,tileFrames5 : ld e,(hl) : inc l : ld d,(hl) : inc l : ld (barrelScroll_AnimFrame5+1),hl
	ld (tilesLUT+2*29),de ;tile to change

	ret	    

barrelScroll_UpdateAdvanceScroll:
    ; update tileMapScroll_H with wraparound
	ld a,(tileMapScroll_H)
	inc a
    cp ((tileMapWidth - SCREEN_TILE_WIDTH) * TILE_SIZE)
    jr nz, 1f
    ld a, 0
1:
	ld (tileMapScroll_H),a 

    ret
