;
; My print routine
; HL: Address of the string
;  D: Character Y position
;  E: Character X position
;
PrintString:           LD A, (HL)              ; Get the character
                        CP 0                    ; CP with 0
                        RET Z                   ; Ret if it is zero
                        INC HL                  ; Skip to next character in string
                        CP 32                   ; CP with 32 (space character)
                        JR C, PrintString      ; If < 32, then don't ouput
                        PUSH DE                 ; Save screen coordinates
                        PUSH HL                 ; And pointer to text string
                        CALL PrintChar         ; Print the character
                        POP HL                  ; Pop pointer to text string
                        POP DE                  ; Pop screen coordinates
                        INC E                   ; Inc to the next character position on screen
                        JR PrintString         ; Loop	
	

;
; Print a single character out to a screen address
;  A: Character to print
;  DE: Screen address
;
;PrintChar:             LD HL, 0x3C00           ; Character set bitmap data in ROM
PrintCharAtScreenAddress:  LD HL, font - 32 * 8           ; Character set bitmap data
                        LD B,0                  ; BC = character code
                        LD C, A
                        SLA C                   ; Multiply by 8 by shifting
                        RL B
                        SLA C
                        RL B
                        SLA C
                        RL B
                        ADD HL, BC              ; And add to HL to get first byte of character
                        JP PrintCharStart



;
; Print a single character out to a screen address
;  A: Character to print
;  D: Character Y position
;  E: Character X position
;
;PrintChar:             LD HL, 0x3C00           ; Character set bitmap data in ROM
PrintChar:             LD HL, font - 32 * 8           ; Character set bitmap data
                        LD B,0                  ; BC = character code
                        LD C, A
                        SLA C                   ; Multiply by 8 by shifting
                        RL B
                        SLA C
                        RL B
                        SLA C
                        RL B
                        ADD HL, BC              ; And add to HL to get first byte of character
                        CALL GetCharAddress   ; Get screen position in DE
						
PrintCharStart:						
                        LD B,4                  ; Loop counter - 8 bytes per character
PrintCharStartLoop1:    LD A,(HL)               ; Get the byte from the ROM into A

						;CPL ; Invert the bits

                        LD (DE),A               ; Stick A onto the screen
                        INC HL                  ; Goto next byte of character
                        INC D                   ; Goto next line on screen
                        DJNZ PrintCharStartLoop1      ; Loop around whilst it is Not Zero (NZ)
						
						SET_PAGE 7
						
						ld BC, 32768
						ADD DE, BC						
					
						LD B,4                  ; Loop counter - 8 bytes per character
PrintCharStartLoop2:    LD A,(HL)               ; Get the byte from the ROM into A

						;CPL ; Invert the bits

                        LD (DE),A               ; Stick A onto the screen
                        INC HL                  ; Goto next byte of character
                        INC D                   ; Goto next line on screen
                        DJNZ PrintCharStartLoop2      ; Loop around whilst it is Not Zero (NZ)						
						
						SET_PAGE 0
						
                        RET
 
; Get screen address from a character (X,Y) coordinate
; D = Y character position (0-23)
; E = X character position (0-31)
; Returns screen address in DE
;
GetCharAddress:       LD A,D
                        AND %00000111
                        RRA
                        RRA
                        RRA
                        RRA
                        OR E
                        LD E,A
                        LD A,D
                        AND %00011000
                        OR %01000000
                        LD D,A
                        RET                             ; Returns screen address in DE	
