cd gfx
call _BUILD_ALL.bat
cd..

cd maps
call _BUILD_ALL.bat
cd..

sjasmplus.exe main.asm

pause
