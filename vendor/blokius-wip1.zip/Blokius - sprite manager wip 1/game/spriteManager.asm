    include "spriteManagerData.asm"

kSpriteSmallCount = 16
kSpriteLargeCount = 8
kSpriteCount = (kSpriteSmallCount + kSpriteLargeCount)


SpriteManager_Init:
	;BIG SPRITES IMAGES
	ld de,SPRITE

	ld ix,spritesList

	ld ix,spritesList+SPRITE ; skip over first player sprite, set up in Player_Init

	; 7x test aliens
	ld hl, testSprite + (SPRITE_LARGE_WIDTH * SPRITE_LARGE_HEIGHT)
	ld b,7

1:
	;attach image
	ld (ix+SPRITE.IMAGE),l : ld (ix+SPRITE.IMAGE+1),h
	;set 
	;static X	
	ld a,b : add a,a : add a,a : add a,a : add 9 : ld (ix+SPRITE.X),a
	add ix,de

	djnz 1b

 	;attach different animations to sprites
	 ;ld a,ANIM_FRAMES_2 : ld (sprite07+SPRITE.MAX_FRAME),a
	 ;ld a,ANIM_SPEED_1 : ld (sprite07+SPRITE.ANIM_SPEED),a

;	 ld a,ANIM_FRAMES_4 : ld (sprite05+SPRITE.MAX_FRAME),a
;	 ld a,ANIM_SPEED_1 : ld (sprite05+SPRITE.ANIM_SPEED),a

;	 ld a,ANIM_FRAMES_4 : ld (sprite03+SPRITE.MAX_FRAME),a
;	 ld a,ANIM_SPEED_2 : ld (sprite03+SPRITE.ANIM_SPEED),a

;	 ld a,ANIM_FRAMES_4 : ld (sprite01+SPRITE.MAX_FRAME),a
;	 ld a,ANIM_SPEED_3 : ld (sprite01+SPRITE.ANIM_SPEED),a


	;SMALL SPRITES IMAGES
	ld ix,spritesList+8*SPRITE : ld hl,testSmallSprite : ld de,SPRITE
	ld b,8
1:
	;attach image
	ld (ix+SPRITE.IMAGE),l : ld (ix+SPRITE.IMAGE+1),h
	;static Y	
	ld a,b : add a,a : add a,a : add a,b : add a,b : add 7 : ld (ix+SPRITE.Y),a
	add ix,de
	djnz 1b	

	;SMALL SPRITES IMAGES
	ld ix,spritesList+16*SPRITE : ld hl,testSmallSprite : ld de,SPRITE
	ld b,8
1:
	;attach image
	ld (ix+SPRITE.IMAGE),l : ld (ix+SPRITE.IMAGE+1),h
	;static Y	
	ld a,b : add a,a : add a,a : add a,b : add a,b : add 7 : ld (ix+SPRITE.Y),a
	add ix,de
	djnz 1b	





;hack to move most aliens off to screen right, so can test collision detection
	ld a, 30
	ld (sprite01_X),a
	ld (sprite02_X),a
	ld (sprite03_X),a
	ld (sprite05_X),a
	ld (sprite06_X),a
	ld (sprite07_X),a


	 
	ret

SpriteManager_Update:
    call SpriteManager_UpdatePositions
    ret

SpriteManager_UpdatePositions:
    ;unrolled for simplicity/speed
    ld hl,(Sprite00Position)
    ld (sprite00_X),hl

    ld hl,(Sprite00Position)
    ld (sprite01_X),hl

    ld hl,(Sprite00Position)
    ld (sprite02_X),hl

    ld hl,(Sprite00Position)
    ld (sprite03_X),hl

    ld hl,(Sprite00Position)
    ld (sprite04_X),hl

    ld hl,(Sprite00Position)
    ld (sprite05_X),hl

    ld hl,(Sprite00Position)
    ld (sprite06_X),hl

    ld hl,(Sprite00Position)
    ld (sprite07_X),hl

    ld hl,(Sprite00Position) 
    ld (sprite08_X),hl

    ld hl,(Sprite00Position)
    ld (sprite09_X),hl

    ld hl,(Sprite00Position)
    ld (sprite10_X),hl

    ld hl,(Sprite00Position)
    ld (sprite11_X),hl

    ld hl,(Sprite00Position)
    ld (sprite12_X),hl

    ld hl,(Sprite00Position)
    ld (sprite13_X),hl

    ld hl,(Sprite00Position)
    ld (sprite14_X),hl

    ld hl,(Sprite00Position)
    ld (sprite15_X),hl

    ld hl,(Sprite00Position)
    ld (sprite16_X),hl

    ld hl,(Sprite00Position)
    ld (sprite17_X),hl

    ld hl,(Sprite00Position)
    ld (sprite18_X),hl

    ld hl,(Sprite00Position)
    ld (sprite19_X),hl

    ld hl,(Sprite00Position)
    ld (sprite20_X),hl

    ld hl,(Sprite00Position)
    ld (sprite21_X),hl

    ld hl,(Sprite00Position)
    ld (sprite22_X),hl

    ld hl,(Sprite00Position)
    ld (sprite23_X),hl

    ret

SpriteManager_AddSprite:
    ret 

SpriteManager_RemoveSprite:
    ret 

