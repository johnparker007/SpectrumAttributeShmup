;MEMORY MAP
;PAGE 0 - SPRITES + FREE - check gfx/resources.a80
;PAGE 1 - FREE (JP trying music in here)
;PAGE 2 - MAIN CODE + FREE (32768-48830)
;PAGE 3 - FREE
;PAGE 4 - TILES CODE 1 + FREE - check gfx/resources.a80 for details
;PAGE 5 - MAIN CODE + FREE	- from 24500-32768
;PAGE 6 - TILES CODE 2 + FREE - check gfx/resources.a80
;PAGE 7 - FREE AFTER SCREEN2

    SLDOPT COMMENT WPMEM, LOGPOINT, ASSERTION
	
    device ZXSPECTRUM128	

	include "defines.asm"
	include "constants.asm"
	include "macros.asm"

;============================================================================
;24500 - 32768                                                              
;============================================================================
	page 0
	org 24500
start:
	;set stack and black border
	di : ld sp,24499 : xor a : out (254),a
	;detect hardware and set fast/slow pages	
	call initHardware
	;fill screens with black
	call fillScreens
	;this one generates shifted copies of tiles and prepare screen for render
	call initTiles	
	
	; JP init music
	; TODO Next thing to try: rebuild song at slow mem address < 32768 - seems to be blank there, and can verify if bank swap is the problem
	; OR: could squeeze a small song into free mem near the end and try that also	
;	SET_PAGE 3
;	ld de, 51310 ; song address
;	call 49152 ;  player address
;	SET_PAGE 0		

;	call musicPlayer

	
	;enable main interrupt, check sys.a80 for details
	ld hl,mainInterrupt  : call IMON	
	;start game
	jp startGame

;--------------------------------------------------------
; data for slow (<32k) ram:
sourceTileMap:
	incbin "maps/tilemap.bin"		

;============================================================================

	assert $<32768, Program code leaks into 32768
	display "FREE SPACE TILL 32768: ",/d,32768-$	

;============================================================================
;32768 - 48830
;============================================================================
	page 0
	org 32768

	include "data.asm"; include this directly after org 32768, so the align 256 tables at the start of data.asm are already on a 256 aligned boundary

;============================================================================
;ENGINE CORE	
;============================================================================
;DEFAULT SETTINGS
	include "engine/defaultSettings.a80"
;ENGINE CORE MUST BE IN FAST MEMORY
	include "engine/core.a80"
;============================================================================
	include "barrelScroll.asm"
	include "hud.asm"
	include "player.asm"
	include "hotspotCollision.asm"
	include "spriteManager.asm" ;  going to need to put this in >55k-ish fast memory location

	include "print.asm"	
	include "math.asm"
	include "Z80-Optimized-Routines-master/math/multiplication/DE_Times_A.z80"
	include "Z80-Optimized-Routines-master/math/subtraction/BC_Minus_A.z80"
	include "MoreOptimisedRoutines/source/16bitValueToAsciiString.asm"
;============================================================================
	;start game
startGame:	
	call barrelScroll_Init

	call SpriteManager_Init

	call Player_Init

	;print score background zeroes
	LD D, CONSOLE_CHAR_X
	LD E, CONSOLE_CHAR_Y
	LD HL, SCORE_INITIAL_TEXT
	CALL PrintString
	
	;DO SOME PRE INIT HERE	
	call enableRender

mainLoop:
;== FRAME 1 =================================================================
	SET_RENDER_FRAME renderFrame2
;============================================================================		

	SET_BORDER COLOR_GREEN
	
	call barrelScroll_Update
	call Player_Update
	;call moveSprites
	call SpriteManager_Update
	;call checkCollisions

;XXX temp hack to make score go up
 ld hl,(sourceTileMapReadIndex)
 ;ld h,0
 ld (scoreValue),hl		

	SET_BORDER COLOR_BLACK
	
;== FRAME 2 =================================================================
	SET_RENDER_FRAME renderFrame1
;============================================================================			

	SET_BORDER COLOR_RED
	
	call DrawHUDAttributes ; needs to be on second frame
	
	SET_BORDER COLOR_BLACK

	jp mainLoop

;============================================================================
;FREE SPACE TILL 48830	
;============================================================================	

initSprites:
; ******************  KEEP THIS FOR REFERENCE UNTIL THE INIT/ADD SPRITE ROUTINES ARE SOLID
; 	;BIG SPRITES IMAGES
; 	ld de,SPRITE

; 	ld ix,spritesList

; 	ld ix,spritesList+SPRITE ; skip over first player sprite, set up in Player_Init

; 	; 7x test aliens
; 	ld hl, testSprite + (SPRITE_LARGE_WIDTH * SPRITE_LARGE_HEIGHT)
; 	ld b,7

; 1:
; 	;attach image
; 	ld (ix+SPRITE.IMAGE),l : ld (ix+SPRITE.IMAGE+1),h
; 	;set 
; 	;static X	
; 	ld a,b : add a,a : add a,a : add a,a : add 9 : ld (ix+SPRITE.X),a
; 	add ix,de

; 	djnz 1b

;  	;attach different animations to sprites
; 	 ;ld a,ANIM_FRAMES_2 : ld (sprite07+SPRITE.MAX_FRAME),a
; 	 ;ld a,ANIM_SPEED_1 : ld (sprite07+SPRITE.ANIM_SPEED),a

; ;	 ld a,ANIM_FRAMES_4 : ld (sprite05+SPRITE.MAX_FRAME),a
; ;	 ld a,ANIM_SPEED_1 : ld (sprite05+SPRITE.ANIM_SPEED),a

; ;	 ld a,ANIM_FRAMES_4 : ld (sprite03+SPRITE.MAX_FRAME),a
; ;	 ld a,ANIM_SPEED_2 : ld (sprite03+SPRITE.ANIM_SPEED),a

; ;	 ld a,ANIM_FRAMES_4 : ld (sprite01+SPRITE.MAX_FRAME),a
; ;	 ld a,ANIM_SPEED_3 : ld (sprite01+SPRITE.ANIM_SPEED),a


; 	;SMALL SPRITES IMAGES
; 	ld ix,spritesList+8*SPRITE : ld hl,testSmallSprite : ld de,SPRITE
; 	ld b,8
; 1:
; 	;attach image
; 	ld (ix+SPRITE.IMAGE),l : ld (ix+SPRITE.IMAGE+1),h
; 	;static Y	
; 	ld a,b : add a,a : add a,a : add a,b : add a,b : add 7 : ld (ix+SPRITE.Y),a
; 	add ix,de
; 	djnz 1b	

; 	;SMALL SPRITES IMAGES
; 	ld ix,spritesList+16*SPRITE : ld hl,testSmallSprite : ld de,SPRITE
; 	ld b,8
; 1:
; 	;attach image
; 	ld (ix+SPRITE.IMAGE),l : ld (ix+SPRITE.IMAGE+1),h
; 	;static Y	
; 	ld a,b : add a,a : add a,a : add a,b : add a,b : add 7 : ld (ix+SPRITE.Y),a
; 	add ix,de
; 	djnz 1b	





; ;hack to move most aliens off to screen right, so can test collision detection
; 	ld a, 60
; 	ld (sprite01_X),a
; 	ld (sprite02_X),a
; 	ld (sprite03_X),a
; 	ld (sprite05_X),a
; 	ld (sprite06_X),a
; 	ld (sprite07_X),a


	 
	ret


; moveSprites:

; ;** move big sprites
; sinPointer: ld hl,sinY : inc l : inc l : inc l : ld (sinPointer+1),hl
; 	ld ix,spritesList+0*SPRITE
; 	ld de,SPRITE

; 	ld b,7 ;  just 7 as skippng player ship sprite 0
; 	add ix,de ; skip 1x sprite index
; 1:
; ;move Y
; 	ld a,(hl) : ld (ix+SPRITE.Y),a : inc l : inc l : inc l : inc l
; 	add ix,de
; 	djnz 1b


; ;** move small sprites
; sinPointer2: ld hl,sinX : inc l : inc l : inc l : ld (sinPointer2+1),hl

; 	ld b,8
; 1:
; ;move X
; 	ld a,(hl) : ld (ix+SPRITE.X),a : inc l : inc l : inc l : inc l
; 	add ix,de
; 	djnz 1b


; 	ld a,64 : add l : ld l,a

; 	ld b,8	
; 1:
; ;move X
; 	ld a,(hl) : ld (ix+SPRITE.X),a : inc l : inc l : inc l : inc l
; 	add ix,de
; 	djnz 1b

; 	ret	

checkCollisions:
	; load stuff into registers
;	ld l, (playerX) ; hotspot
;	add l

	ld a, (Sprite00Y) 
	add SPRITE_LARGE_HEIGHT / 2
	ld h, a

	ld a, (Sprite00X) 
	add SPRITE_LARGE_WIDTH / 2
	ld l, a

											;ret

	ld bc, (sprite04_X) ;
	;ld c, ((spritesList + 1 * SPRITE) + SPRITE.X) ; rect x
	ld d, SPRITE_LARGE_HEIGHT ; rect height
	ld e, SPRITE_LARGE_WIDTH ; rect width

	call hotspotDetectRect

    jr nc, 1f ; Check carry flag
    call processCollision ; carry flag set, process collision

1: ; jumps forward to here 
	ret

processCollision:
	ld h, (PLAYER_MIN_X + 2)
	ld l, (PLAYER_MIN_Y + 2)
	;ld (playerPosition), hl
	ld (Sprite00Position),hl

	ret

;============================================================================
	;WARNING IF HIT IM TABLE
	assert $<48830, Program code leaks into IM2 vector area
	;display free space till #bebe
	display "FREE SPACE TILL VECTOR TABLE: ",/d,48830-$
;============================================================================
;ENGINE RESOURCES IN DIFFERENT PAGES
;check memory map and resources.a80 for details
;============================================================================
	;include resources in pages
	include "gfx/resources.a80"
	include "music/resources.a80"	
;===========================================================================
; Stack. SEEMS NEEDED FOR DEZOG DEBUGGER, taken from sample project
;===========================================================================


; Stack: this area is reserved for the stack
STACK_SIZE: equ 100    ; in words


; Reserve stack space
    defw 0  ; WPMEM, 2
stack_bottom:
    defs    STACK_SIZE*2, 0
stack_top:
    ;defw 0
    defw 0  ; WPMEM, 2


;GENERATE SIMPLE TAP LOADER AT THE END
;============================================================================





	page 0
	include "engine/loader.a80"

    SAVESNA "main.sna", start

	IF (_ERRORS = 0)                                 		
			SHELLEXEC "main.tap"	
	ENDIF
