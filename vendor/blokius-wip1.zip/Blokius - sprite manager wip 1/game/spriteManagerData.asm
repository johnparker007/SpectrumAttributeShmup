    STRUCT SPRITE_STRUCT
type        BYTE 0
x			BYTE 0
y			BYTE 0
vX	        BYTE 0
vY	        BYTE 0
energy      BYTE 0
    ENDS   


SpriteData:
Sprite00:
Sprite00Position:
Sprite00X:
    db 0
Sprite00Y:
    db 0
Sprite00Vx:
    db 0
Sprite00Vy:
    db 0
Sprite00Energy:
    db 0

Sprite01:
Sprite01Position:
Sprite01X:
    db 0
Sprite01Y:
    db 0
Sprite01Vx:
    db 0
Sprite01Vy:
    db 0
Sprite01Energy:
    db 0

Sprite02:
Sprite02Position:
Sprite02X:
    db 0
Sprite02Y:
    db 0
Sprite02Vx:
    db 0
Sprite02Vy:
    db 0
Sprite02Energy:
    db 0

Sprite03:
Sprite03Position:
Sprite03X:
    db 0
Sprite03Y:
    db 0
Sprite03Vx:
    db 0
Sprite03Vy:
    db 0
Sprite03Energy:
    db 0

Sprite04:
Sprite04Position:
Sprite04X:
    db 0
Sprite04Y:
    db 0
Sprite04Vx:
    db 0
Sprite04Vy:
    db 0
Sprite04Energy:
    db 0

Sprite05:
Sprite05Position:
Sprite05X:
    db 0
Sprite05Y:
    db 0
Sprite05Vx:
    db 0
Sprite05Vy:
    db 0
Sprite05Energy:
    db 0

Sprite06:
Sprite06Position:
Sprite06X:
    db 0
Sprite06Y:
    db 0
Sprite06Vx:
    db 0
Sprite06Vy:
    db 0
Sprite06Energy:
    db 0

Sprite07:
Sprite07Position:
Sprite07X:
    db 0
Sprite07Y:
    db 0
Sprite07Vx:
    db 0
Sprite07Vy:
    db 0
Sprite07Energy:
    db 0

Sprite08:
Sprite08Position:
Sprite08X:
    db 0
Sprite08Y:
    db 0
Sprite08Vx:
    db 0
Sprite08Vy:
    db 0
Sprite08Energy:
    db 0

Sprite09:
Sprite09Position:
Sprite09X:
    db 0
Sprite09Y:
    db 0
Sprite09Vx:
    db 0
Sprite09Vy:
    db 0
Sprite09Energy:
    db 0

Sprite10:
Sprite10Position:
Sprite10X:
    db 0
Sprite10Y:
    db 0
Sprite10Vx:
    db 0
Sprite10Vy:
    db 0
Sprite10Energy:
    db 0

Sprite11:
Sprite11Position:
Sprite11X:
    db 0
Sprite11Y:
    db 0
Sprite11Vx:
    db 0
Sprite11Vy:
    db 0
Sprite11Energy:
    db 0

Sprite12:
Sprite12Position:
Sprite12X:
    db 0
Sprite12Y:
    db 0
Sprite12Vx:
    db 0
Sprite12Vy:
    db 0
Sprite12Energy:
    db 0

Sprite13:
Sprite13Position:
Sprite13X:
    db 0
Sprite13Y:
    db 0
Sprite13Vx:
    db 0
Sprite13Vy:
    db 0
Sprite13Energy:
    db 0

Sprite14:
Sprite14Position:
Sprite14X:
    db 0
Sprite14Y:
    db 0
Sprite14Vx:
    db 0
Sprite14Vy:
    db 0
Sprite14Energy:
    db 0

Sprite15:
Sprite15Position:
Sprite15X:
    db 0
Sprite15Y:
    db 0
Sprite15Vx:
    db 0
Sprite15Vy:
    db 0
Sprite15Energy:
    db 0

Sprite16:
Sprite16Position:
Sprite16X:
    db 0
Sprite16Y:
    db 0
Sprite16Vx:
    db 0
Sprite16Vy:
    db 0
Sprite16Energy:
    db 0

Sprite17:
Sprite17Position:
Sprite17X:
    db 0
Sprite17Y:
    db 0
Sprite17Vx:
    db 0
Sprite17Vy:
    db 0
Sprite17Energy:
    db 0

Sprite18:
Sprite18Position:
Sprite18X:
    db 0
Sprite18Y:
    db 0
Sprite18Vx:
    db 0
Sprite18Vy:
    db 0
Sprite18Energy:
    db 0

Sprite19:
Sprite19Position:
Sprite19X:
    db 0
Sprite19Y:
    db 0
Sprite19Vx:
    db 0
Sprite19Vy:
    db 0
Sprite19Energy:
    db 0

Sprite20:
Sprite20Position:
Sprite20X:
    db 0
Sprite20Y:
    db 0
Sprite20Vx:
    db 0
Sprite20Vy:
    db 0
Sprite20Energy:
    db 0

Sprite21:
Sprite21Position:
Sprite21X:
    db 0
Sprite21Y:
    db 0
Sprite21Vx:
    db 0
Sprite21Vy:
    db 0
Sprite21Energy:
    db 0

Sprite22:
Sprite22Position:
Sprite22X:
    db 0
Sprite22Y:
    db 0
Sprite22Vx:
    db 0
Sprite22Vy:
    db 0
Sprite22Energy:
    db 0

Sprite23:
Sprite23Position:
Sprite23X:
    db 0
Sprite23Y:
    db 0
Sprite23Vx:
    db 0
Sprite23Vy:
    db 0
Sprite23Energy:
    db 0
    